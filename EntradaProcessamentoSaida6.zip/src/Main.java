import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê o nome do produto
        System.out.println("Digite o nome do produto:");
        String nomeProduto = scanner.nextLine();

        // Solicita e lê o preço do produto
        System.out.println("Digite o preço do produto:");
        double precoProduto = scanner.nextDouble();

        // Solicita e lê o percentual de desconto
        System.out.println("Digite o percentual de desconto:");
        double percentualDesconto = scanner.nextDouble();

        // Fecha o Scanner após a leitura dos dados
        scanner.close();

        // Calcula o valor do desconto
        double desconto = precoProduto * (percentualDesconto / 100);

        // Calcula o novo preço com desconto
        double novoPreco = precoProduto - desconto;

        // Exibe o nome do produto e o novo preço com desconto
        System.out.println("Nome do produto: " + nomeProduto);
        System.out.println("Novo preço com desconto: " + novoPreco);
    }
}
