import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê as duas notas
        System.out.println("Digite a primeira nota:");
        double nota1 = scanner.nextDouble();

        System.out.println("Digite a segunda nota:");
        double nota2 = scanner.nextDouble();

        // Fecha o Scanner após a leitura das notas
        scanner.close();

        // Calcula a média das duas notas
        double media = (nota1 + nota2) / 2;

        // Exibe a média das notas
        System.out.println("A média das duas notas é: " + media);
    }
}
