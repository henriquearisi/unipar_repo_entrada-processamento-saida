import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê as quatro notas
        System.out.println("Digite a primeira nota:");
        double nota1 = scanner.nextDouble();

        System.out.println("Digite a segunda nota:");
        double nota2 = scanner.nextDouble();

        System.out.println("Digite a terceira nota:");
        double nota3 = scanner.nextDouble();

        System.out.println("Digite a quarta nota:");
        double nota4 = scanner.nextDouble();

        // Fecha o Scanner após a leitura das notas
        scanner.close();

        // Calcula a média das quatro notas
        double media = (nota1 + nota2 + nota3 + nota4) / 4;

        // Exibe a média das notas
        System.out.println("A média das quatro notas é: " + media);
    }
}
