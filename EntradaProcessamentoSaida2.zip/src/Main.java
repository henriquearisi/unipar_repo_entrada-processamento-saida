import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê os dois valores
        System.out.println("Digite o primeiro valor:");
        double valor1 = scanner.nextDouble();

        System.out.println("Digite o segundo valor:");
        double valor2 = scanner.nextDouble();

        // Fecha o Scanner após a leitura dos valores
        scanner.close();

        // Calcula a subtração dos dois valores
        double resultado = valor1 - valor2;

        // Exibe o resultado da subtração
        System.out.println("A subtração dos dois valores é: " + resultado);
    }
}
